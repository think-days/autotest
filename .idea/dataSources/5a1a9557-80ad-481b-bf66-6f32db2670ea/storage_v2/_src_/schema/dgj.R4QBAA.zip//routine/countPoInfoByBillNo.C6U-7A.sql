create
    definer = dbdgj@`%` procedure countPoInfoByBillNo(IN billNos varchar(3000))
BEGIN
set @sel1 = "select a.id as 'info行id',
                         a.billNo as '单号',
                         a.skuId,
                         a.sQty-ifnull(b.inQty,0) as '未入库数量',
                         a.sQty as '源单数量',
                          a.isGift as '是否赠品',
                          a.price as '单价',
                         b.inQty as '入库数量',
                         b.toInQty as '待入库数量',
                         ifnull(c.cQty, 0) as cQty as '关闭数量'
                  from (
                           select id, skuId, sum(qty) as sQty, billNo, price, isGift
                           from t_scm_po_order_info
                           where billNo in(";
set @sel2 = ")
#                              and sid < 9000
                             and isDelete = 0
                           group by id) as a
                           left join
                       (
                           select srcOrderEntryId,
                                  skuId,
                                  billStatus,
                                  sum(if(billStatus = 1, qty, 0)) as inQty,
                                  sum(if(billStatus = 0, qty, 0)) as toInQty
                           from t_scm_po_out_info
                           where srcOrderNo in(";
set @sel3 = ")
                             and isDelete = 0
                           group by srcOrderEntryId) as b on a.id = b.srcOrderEntryId
                           left join
                       (
                           select sum(qty) as cQty, srcOrderEntryId
                           from t_scm_po_close_info
                           where billNo in (";
set @sel4 = ")
                             and isDelete = 0
                           group by srcOrderEntryId
                       ) as c on a.id = c.srcOrderEntryId;";

set @sentence = concat(@sel1, billNos, @sel2, billNos, @sel3, billNos, @sel4); -- 连接字符串生成要执行的SQL语句

prepare stmt from @sentence; -- 预编释一下。 “stmt”预编释变量的名称，
execute stmt; -- 执行SQL语句
deallocate prepare stmt; -- 释放资源
END;

